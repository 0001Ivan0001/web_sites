import "./head.css";
import {Link} from "react-router-dom";

function Head(){
    return(
        <div>
        <h1>Занимательная информатика в развитии логического мышления </h1>
        </div>
)
}
export default Head;