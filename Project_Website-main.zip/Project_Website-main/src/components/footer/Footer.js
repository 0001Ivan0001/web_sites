import "./footer.css";

function Footer(){
    return(
        <div className = "footer-content">
            <h4>(c) ЮФУ, 2023. Бабенко А.В., Глазко И.В., Насибян А.А., Шовгеня Е.А.</h4>
        </div>
    );
}
export default Footer;